﻿namespace UnityEditor.PackageManager.UI
{
    internal enum PackageTag
    {
        preview,
        verified,
        inDevelopment,
        local
    }
}
