﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    // Start is called before the first frame update
   // int a = 1;
    public Rigidbody rb;
    public float forwardsForce = 1000;
    void Start()
    {
        Debug.Log("Start!!!");    
       // rb.AddForce(0,0,1000);
    }

    // Update is called once per frame
    void Update()
    {
        /*Debug.Log(a);
        a++;*/

        rb.AddForce(0, 0, forwardsForce * Time.deltaTime/2);
        if (Input.GetKey("a")) {
            rb.AddForce(-1000 * Time.deltaTime,0,0);
;        }
        if (Input.GetKey("d")) {
            rb.AddForce(1000 * Time.deltaTime, 0, 0);
        }

        
    }

    
}
